package it.epicode.be.godfather.model;

public class DrinkLemonade extends Drink {

	public DrinkLemonade() {
		super("Lemonade", 1.29, 128d);
	}

}
