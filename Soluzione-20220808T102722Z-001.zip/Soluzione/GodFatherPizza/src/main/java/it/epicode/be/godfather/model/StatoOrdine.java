package it.epicode.be.godfather.model;

public enum StatoOrdine {
	IN_CORSO,
	PRONTO,
	SERVITO;

}
