package it.epicode.be.godfather.model;

public interface Pizza extends FoodItem {

}
