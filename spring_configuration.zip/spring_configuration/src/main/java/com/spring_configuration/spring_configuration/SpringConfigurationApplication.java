package com.spring_configuration.spring_configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringConfigurationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringConfigurationApplication.class, args);
	}

}
